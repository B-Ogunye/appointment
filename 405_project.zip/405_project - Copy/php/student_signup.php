<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
     <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>
    <style>
    	body {
    		background-color: #CCCCFF;
    	}
    	.box1 {
    		padding-top: 10px;
    	}
    	.profilePic img {
    		border: 0.3px;
    		border-radius: 50%;
    		border-style:solid;
    		position: relative;
    		left: 70px;
    		top: 100px;
    	}
    	.profilePic h4 {
    		position: relative;
    		left: 70px;
    		top: 100px;
    	}
    	input[type=text], input[type=password] {
		    width: 100%;
		    padding: 15px;
		    margin: 5px 0 22px 0;
		    display: inline-block;
		    border: none;
		    background: #f1f1f1;
		}

		input[type=text]:focus, input[type=password]:focus {
		    background-color: #ddd;
		    outline: none;
		}

		hr {
		    border: 1px solid #f1f1f1;
		    margin-bottom: 25px;
		}

		/* Set a style for all buttons */
		button {
		    background-color: rgb(57, 28, 185);
		    color: white;
		    padding: 14px 20px;
		    margin: 8px 0;
		    border: none;
		    cursor: pointer;
		    width: 100%;
		    opacity: 0.9;
		}

		button:hover {
		    opacity:1;
		}

		.signupbtn {
		  width: 50%;
		}

		.topnav {
			background-color: black;
			color: white;
			height: 50px;
			border: none;
			border-radius: 4px;
			font-weight: 10px;
			font-size: 30px;
			font-style: oblique;
			font-family: sans-serif;
		}
    </style>
</head>
<body>
	<nav class="topnav" >
			<div class="container-fluid">
			    Sign Up
			</div>
		</nav>
	</nav>
	<div class="container">
		<div class="box1">
			<div class="row">
				<div class="col-md-9">
					<form name="student" action="#">
						<h1>Student Sign Up</h1>
						<hr>
						<p>
							<label for="firstName"><b>First Name</b></label><br>
							<input type="text" placeholder="Enter First Name" name="firstName" required="true">
						</p>
						<p>
							<label for="lastName"><b>Last Name</b></label><br>
							<input type="text" placeholder="Enter Last Name" name="lastName" required="true">
						</p>
						<p>
							<label for="email"><b>Email</b></label><br>
							<input type="text" placeholder="Enter Email" name="email" required="true">
						</p>
						<p>
							<label for="username"><b>Matric No</b></label><br>
							<input type="text" placeholder="Enter Matric No" name="matric" required="true">
						</p>
						<p>
							<label for="password"><b>Password</b></label><br>
							<input type="text" placeholder="Password" name="password" required="true">
						</p>
						<a href="student_dashboard.php"><button type="submit" class="signupbtn">Sign Up</button></a>
			            <br>
			            <p>Already have an account?<a href="index.php">Login</a></p>
			        </form>
				</div>
			
				<div class="col-md-3">
					<div class="profilePic">
			        	<img src="profile.jpg" alt="Avatar" style="width: 200px">
			        	<h4><b>Upload a profile picture</h4>
			        </div>
				</div>
            </div>
		</div>
    </div>
</body>
</html>