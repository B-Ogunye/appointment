<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
     <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>

    <style>
    	body {
			background-color: #CCCCFF
		}
		.mybtn, .mybtn2 button:hover {
		    opacity: 0.9;
		}
		.mybtn, .mybtn2{
			width: 200px;
			margin: 8px 0px;
			padding: 10px 10px;
			color: white;
			border: 0.5px;
			border-radius: 4px;
			opacity: 0.7;
		}
		.mybtn {
			background-color: rgb(70, 10, 30);
			border: none;
			
		}

		.mybtn2 {
			background-color: rgb(100, 150, 50);
			border: none;
		}
		.sendbtn { 
			background-color: #990099;
			width: 150px;
		    
		}
		.sendbtn button:hover {
		    opacity:0.5;
		}
		.cancelbtn { 
			background-color: #FF0000;
			width: 200px;
		    
		}
		.cancelbtn button:hover {
		    opacity:0.5;
		}

		.sendbtn, .cancelbtn {
			
		    display: inline;
		    color: white;
		    text-decoration: none;
		    text-align: center;
		    padding: 10px 10px;
		    margin: 8px 0;
		    border: none;
		    border-radius: 4px;
		    cursor: pointer;
		    opacity: 0.9;
		}
		.topnav {
			background-color: black;
			color: white;
			height: 50px;
			border: none;
			border-radius: 4px;
			font-weight: 10px;
			font-size: 30px;
			font-style: oblique;
			font-family: sans-serif;
		}

		
    </style>
</head>
<body>
	<nav class="topnav" >
		<div class="container-fluid">
		    Navigate
		</div>
	</nav>
	
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<h2>Welcome John Doe, click on any of the buttons below to navigate.</h2>
				<br>
				<h4>Book Appoinment</h4>
				<p>Available day that the supervisor will be free</p><a href="book_appointment.php">
				<button type="submit" class="mybtn"><i class="fa fa-pencil-square-o" style="font-size: 17px; "></i> Book Appointment</button></a><br>

				<h4>Reschedule Appoinment</h4>
				<p>You can only reschedule your appointment 10 hours before the stipulated one. Remember to send an email.</p>
				<button type="submit" class="mybtn2" onclick="return confirm('Are you sure you want to reschedule appointments?');"><i class="fa fa-history" style="font-size: 17px; "></i> Reschedule Appointment</button><br>

				<h4>Cancel Appoinment</h4>
				<p>You can only cancel your appointment 10 hours before the stipulated one. Remember to send an email.</p>
				<button type="submit" class="cancelbtn" onclick="return confirm('Are you sure you want to cancel appointments?');"><i class="fa fa-close" style="font-size: 17px; "></i> Cancel Appointment</button><br>

				<h4>Send Mail</h4>
				<p>Send an email to your supervisor if you have any issues.</p>
				<button type="submit" class="sendbtn"><i class="fa fa-envelope" style="font-size: 17px; "></i> Send Mail</button>
			</div>

			<div class="col-md-4">
				<h3>You</h3>
				<img src="profile.jpg" style="width: 200px; border-radius: 50%; border: none;">
				<h4>Jane Doe</h4>
				
			</div>
		</div>


	</div>

	<script>
		function show(){
			alert('Your appointment has been booked successfully!')
		}

		
	</script>
</body>
</html>