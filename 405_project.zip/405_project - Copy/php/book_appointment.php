<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
     <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>
    <style>
    	.book {
    		border: 1px solid black;
    		padding: 30px;
    	}

    	

    </style>
</head>

<body>
	<nav class="topnav" >
		<div class="container-fluid">
		   BOOK AN APPOINTMENT
		</div>
	</nav>
	
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<h1>Welcome John Doe,</h1> 
				<h2>Click on any of the convenient times to book an appointment.</h2><br>
				<form name="box" action="#" class="book">
					<div id="radiobtn" class="radio">
		  				<input type="radio" name="optradio" value="1">
		  					<h3>Wednesday</h3>
		  					<h4>3-5</h4>
		  				<input type="radio" name="optradio" value="2">
					  		<h3>Saturday</h3>
		  					<h4>3-5</h4>
		  				<input type="radio" name="optradio" value="3">
					  		<h3>Friday</h3>
		  					<h4>3-5</h4>
		  				<input type="radio" name="optradio" value="4">
					  		<h3>Friday</h3>
		  					<h4>3-5</h4>
					</div>

					<button type="submit" class="mybtn" onclick="show();"><i class="fa fa-pencil-square-o" style="font-size: 17px; "></i> Book Appointment</button>
				</form>
			</div>
			<div class="col-md-4">
				<form name="profilePic" class="profilePic">
				<h3>Your supervisor</h3>
				<img src="profile.jpg" style="width: 200px; border-radius: 50%; border: none;">
				<h4>Jane Doe</h4>
			</div>
		</div>
		
		<br>
		
	</div>




	<script>
		function show(){
			var radios = document.getElementByName('optradio');
		
			var i = 0;
			while (i < radios.length){
				if (radios[1].checked == true){
					
					alert('Your appointment has been booked successfully!');
				}
				else if (radios[2].checked == true){
					alert('Your appointment has been booked successfully!');
				}
				else if (radios[3].checked == true){
					alert('Your appointment has been booked successfully!');
				}
				else if (radios[4].checked == true){
					alert('Your appointment has been booked successfully!');
				}
				else{
					alert('You have not made a selection');
					return false;
				}
			}
			return true;
		}
	</script>
</body>
</html>