<!DOCTYPE html>
<html>
<head>
	<title>Document</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
     <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>

    <style>

    	body {
    		background-color: #CCCCFF;
    	}
    	.box1 {
    		padding-top: 100px;
    	}
    	input[type=text], input[type=password] {
		    width: 100%;
		    padding: 15px;
		    margin: 5px 0 22px 0;
		    display: inline-block;
		    border: none;
		    background: #f1f1f1;
		}

		input[type=text]:focus, input[type=password]:focus {
		    background-color: #ddd;
		    outline: none;
		}
    	hr {
		    border: 1px solid #f1f1f1;
		    margin-bottom: 25px;
		}

		/* Set a style for all buttons */
		button {
		    background-color: rgb(57, 28, 185);
		    color: white;
		    padding: 14px 20px;
		    margin: 8px 0;
		    border: none;
		    cursor: pointer;
		    width: 100%;
		    opacity: 0.9;
		}

		button:hover {
		    opacity:1;
		}
		@media screen and (max-width: 300px) {
		    .cancelbtn, .signupbtn {
		       width: 100%;
		    }
		}

		.signupbtn {
		  float: left;
		  width: 50%;
		}

		.topnav {
			background-color: black;
			color: white;
			height: 50px;
			border: none;
			border-radius: 4px;
			font-weight: 10px;
			font-size: 30px;
			font-style: oblique;
			font-family: sans-serif;
		}
    </style>
</head>
<body>
	<nav class="topnav" >
			<div class="container-fluid">
			    Home Page
			</div>
		</nav>
	<div class="container">
		<div class="header">
			<h2>Welcome to BOOK A-PPOINTMENT</h2>
		</div>
		<div class="box1">
			<div class="row">
				<div class="col-md-4">
					<form name="supervisor_login" action="#">
						<h1>Supervisor Login</h1>
						<hr>
						<p>
							<label for="username"><b>Username</b></label><br>
							<input type="text" placeholder="Username" name="username" required="true">
						</p>
						<p>
							<label for="password"><b>Password</b></label><br>
							<input type="text" placeholder="Password" name="password" required="true">
						</p>
						<p>
							<label>
								<input type="checkbox" checked="checked" name="remember">
								Remember me
							</label>
						</p>
						<a href="view_appointment.php"><button type="submit" class="loginbtn">Log In</button></a>
		                <br>
		                <p>Don't have an account?<a href="supervisor_signup.php"> Sign up</a></p>
	                </form>
                </div>
			
				<div class="col-md-4">

					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit ultricies nibh fermentum pretium. Mauris lacinia aliquet nunc, quis pretium libero euismod sit amet. Suspendisse laoreet ultricies tortor sed pulvinar. Etiam at accumsan nibh. Proin auctor purus ac diam pharetra ultrices. In hac habitasse platea dictumst. Vivamus ornare sodales accumsan. Nunc varius auctor pharetra. Quisque vulputate sagittis mauris, quis ultricies urna viverra in. Maecenas euismod augue in nibh dapibus, nec consectetur velit luctus. Cras varius erat eget lorem aliquet, gravida egestas lorem egestas. Fusce condimentum lobortis diam quis commodo. Nam eleifend tortor sed ante auctor, ullamcorper tempus ex facilisis.

					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam nec sem ac ligula efficitur vehicula in id lacus. Integer porttitor sem a lectus commodo, non maximus ipsum varius. Mauris mollis et velit eget tincidunt. Nunc lobortis dolor neque, pulvinar tincidunt neque imperdiet non. Morbi lacinia odio et lacus varius aliquet. In vel varius dui. Integer rutrum convallis nulla, at accumsan felis fermentum id. Nullam et varius metus, eu pretium dui. Maecenas tempus lorem ipsum, ut porta metus sodales ac. Sed dignissim convallis arcu, vel laoreet elit. Morbi ornare sagittis mi non imperdiet. Sed efficitur vitae sapien malesuada auctor. Aenean dignissim erat sed bibendum congue. Morbi vitae enim maximus, lacinia lorem nec, maximus arcu. Praesent mi ligula, dignissim in dapibus sed, ultricies eu sem.
				</div>

				<div class="col-md-4">
					<form name="student_login" action="#">
						<h1>Student Login</h1>
						<hr>
						<p>
							<label for="username"><b>Matric No</b></label><br>
							<input type="text" placeholder="Matric No" name="matric" required="true">
						</p>
						<p>
							<label for="password"><b>Password</b></label><br>
							<input type="text" placeholder="Password" name="password" required="true">
						</p>
						<p>
							<label>
								<input type="checkbox" checked="checked" name="remember">
								Remember me
							</label>
						</p>
						<a href="student_dashboard.php"><button type="submit" class="loginbtn">Log In</button></a>
		                <br>
		                <p>Don't have an account?<a href="student_signup.php"> Sign up</a></p>
	                </form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>