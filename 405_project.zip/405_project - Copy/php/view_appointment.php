<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
     <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>
</head>

<body>
	<div class="container-fluid">
		<nav class="topnav" >
			<div class="container-fluid">
			    No of appointments for the day:
			</div>
		</nav>
		<div class=" cover container" >
			<div class="row">
				<div class="col-md-8">
					<h2>Welcome John Doe, here is your appointment list.</h2><hr style="color: ">
					<form name="box" class="box">
						<h3>Wednesday</h3>
						<ul class="fa-ul">
			  				<li><i class="fa-li fa fa-check-square" style="font-size: 36px; color: #d7bde2;"></i>
			  					<img src="profile.jpg">
			  					<h4>Jane Doe</h4><br>
				  				<button type="submit" class="cancelbtn"><i class="fa fa-close" style="font-size: 17px; "></i> Cancel</button>
				  				<button type="submit" class="sendbtn"><i class="glyphicon glyphicon-envelope"></i> Send Mail</button>
				  			</li>	
			  				<li><i class="fa-li fa fa-check-square" style="font-size: 36px; color: #d7bde2;"></i>
			  					<img src="profile.jpg">
			  					<h4>Lagbaja</h4><br>
				  				<button type="submit" class="cancelbtn"><i class="fa fa-close" style="font-size: 17px; "></i> Cancel</button>
				  				<button type="submit" class="sendbtn"><i class="glyphicon glyphicon-envelope"></i> Send Mail</button>
				  			</li>
						</ul>
						<h3>Saturday</h3>
						<ul class="fa-ul">
			  				<li><i class="fa-li fa fa-check-square" style="font-size: 36px; color: #d7bde2;"></i>
			  					<img src="profile.jpg">
			  					<h4>Dave Ire</h4><br>
				  				<button type="submit" class="cancelbtn"><i class="fa fa-close" style="font-size: 17px; "></i> Cancel</button>
				  				<button type="submit" class="sendbtn"><i class="glyphicon glyphicon-envelope"></i> Send Mail</button>
							</li>
						
			  				<li><i class="fa-li fa fa-check-square" style="font-size: 36px; color: #d7bde2;"></i>
			  					<img src="profile.jpg">
			  					<h4>John Doe</h4><br>
				  				<button type="submit" class="cancelbtn"><i class="fa fa-close" style="font-size: 17px; "></i> Cancel</button>
				  				<button type="submit" class="sendbtn"><i class="glyphicon glyphicon-envelope"></i> Send Mail</button>
							</li>
						</ul>
					</form>
				</div>
				<div class="col-md-4">
					<div class="settings">
						<h2>Settings <i class="fa fa-cog" style="font-size: 36px; color: #6633CC;"></i></h2>
						<form name="appointmentForm">
							<div id="appointment">
								<h3>Appointment 1</h3>
									<ul class="fa-ul">
							        	<li><i class="fa-li fa fa-calendar" style="font-size: 15px; color: #6633CC;"></i><h4> Set Day
						        		<select name="setDay">
						        			<option value="sunday">Sunday</option>
				                            <option value="monday">Monday</option>
				                            <option value="tuesday">Tuesday</option>
				                            <option value="wednesday">Wednesday</option>
				                            <option value="thursday">Thursday</option>
				                            <option value="friday">Friday</option>
				                            <option value="saturday">Saturday</option>
				                        </select></h4>
						        	</li> 	
						        	
								    <li><i class="fa-li fa fa-clock-o" style="font-size: 15px; color: #6633CC;"></i><h4> Set Time
								    	<!--<form name="set_time">
								    		<input id="view_inputHour" name="inputHour" type="text" name="setTime" value="">
						        			<button onclick="increaseHour();""><span class="fa fa-caret-up" ></span></button>
						        			<button><span class="fa fa-caret-down" onclick="decreaseHour();"></span></button>
				                       		 <input id="view_inputMin" name="inputMin" type="text" name="setTime">
						        			<button><span class="fa fa-caret-up" onclick="increaseMin();"></span></button>
						        			<button><span class="fa fa-caret-down" onclick="decreaseMin();"></span></button>
					                        
								    	</form>-->

								    	<select name="setHour">
						        			<option value="one">01</option>
				                            <option value="two">02</option>
				                            <option value="three">03</option>
				                            <option value="four">04</option>
				                            <option value="five">05</option>
				                            <option value="six">06</option>
				                            <option value="seven">07</option>
				                            <option value="eight">08</option>
				                            <option value="nine">09</option>
				                            <option value="ten">10</option>
				                            <option value="eleven">11</option>
				                            <option value="twelve">12</option>
				                        </select>
				                        :
				                        <select name="setMin">
						        			<option value="full">00</option>
				                            <option value="half">30</option>
				                            
				                        </select>
				                        <select>
						        			<option value="am">AM</option>
				                            <option value="pm">PM</option>
				                        </select></h4>
						        		
						        	</li> 

						        	<li><i class="fa-li fa fa-exclamation-triangle" style="font-size: 15px; color: #6633CC;"></i><h4>Maximum number of students
						        		<select name="maxStudents">
						        			<option value="one">01</option>
				                            <option value="two">02</option>
				                            <option value="three">03</option>
				                            <option value="four">04</option>
				                            <option value="five">05</option>
				                        </select></h4>
						        	</li> 		
							    </ul>
							    <button type="submit" class="setbtn"><strong>Set</strong></button>
							
							
								<h3>Appointment 2</h3>
								<ul class="fa-ul">
						        	<li><i class="fa-li fa fa-calendar" style="font-size: 15px; color: #6633CC;"></i><h4>Set Day
						        		<select name="setDay">
						        			<option value="sunday">Sunday</option>
				                            <option value="monday">Monday</option>
				                            <option value="tuesday">Tuesday</option>
				                            <option value="wednesday">Wednesday</option>
				                            <option value="thursday">Thursday</option>
				                            <option value="friday">Friday</option>
				                            <option value="saturday">Saturday</option>
				                        </select></h4>
						        	</li> 	
						        	
								    <li><i class="fa-li fa fa-clock-o" style="font-size: 15px; color: #6633CC;"></i><h4>Set Time
								    	<select name="setHour">
						        			<option value="one">01</option>
				                            <option value="two">02</option>
				                            <option value="three">03</option>
				                            <option value="four">04</option>
				                            <option value="five">05</option>
				                            <option value="six">06</option>
				                            <option value="seven">07</option>
				                            <option value="eight">08</option>
				                            <option value="nine">09</option>
				                            <option value="ten">10</option>
				                            <option value="eleven">11</option>
				                            <option value="twelve">12</option>
				                        </select>
				                        :
				                        <select name="setMin">
						        			<option value="full">00</option>
				                            <option value="half">30</option>
				                            
				                        </select>
				                        <select>
						        			<option value="am">AM</option>
				                            <option value="pm">PM</option>
				                        </select></h4>
						        		
					        		<li><i class="fa-li fa fa-exclamation-triangle" style="font-size: 15px; color: #6633CC;"></i><h4>Maximum number of students
						        		<select name="setDate">
						        			<option value="one">01</option>
				                            <option value="two">02</option>
				                            <option value="three">03</option>
				                            <option value="four">04</option>
				                            <option value="five">05</option>
				                        </select></h4>
						        	</li> 		
						        	</li> 	
							    </ul>
							    <button type="submit" class="setbtn"><strong>Set</strong></button>
							    <br><br>
							    <button type="button" style="border-radius: 4px; background-color: #d7bde2; border: none;" onclick="add();"><strong>Click to add more appointment dates</strong></button>

							    <div id="appointmentExtra"></div>
							</div>
							
						</form>

						
					</div>
				</div>
			</div>
		</div>
	</div>


	<script type="text/javascript">

		function add(){
			var number = 5;
			var appointmentExtra = document.getElementById('appointmentExtra');

			while (appointmentExtra.hasChildNodes()){
				appointmentExtra.removeChild(container.lastChild);
			}
			for (i = 0; i < number; i++){
				appointmentExtra.appendChild(document.createTextNode("Appointment " + (i + 3)));
				var d = "<h3>Appointment 2</h3> \n" +
			"	<ul>\n" +
		    "     	<li><h4>Set Day\n" +
		    "     		<select name=\"setDay\">\n" +
		    "     			<option value=\"sunday\">Sunday</option>\n" +
            "                <option value=\"monday\">Monday</option>\n" +
            "                <option value=\"tuesday\">Tuesday</option>\n" +
            "                <option value=\"wednesday\">Wednesday</option>\n" +
            "                <option value=\"thursday\">Thursday</option>\n" +
            "                <option value=\"friday\">Friday</option>\n" +
            "                <option value=\"saturday\">Saturday</option>\n" +
            "            </select></h4>\n" +
		    "    	</li> \n"	+
		    "		<li><h4>Set Time\n" +
			"	    	<select name=\"setHour\">\n" +
		    "    			<option value=\"one\">01</option>\n" +
            "                <option value=\"two\">02</option>\n" +
            "                <option value=\"three\">03</option>\n" +
            "                <option value=\"four\">04</option>\n" +
            "                <option value=\"five\">05</option>\n" =
            "                <option value=\"six\">06</option>\n" +
            "                <option value=\"seven\">07</option>\n" =
            "                <option value=\"eight\">08</option>\n" +
            "                <option value=\"nine\">09</option>\n" +
            "                <option value=\"ten\">10</option>\n" +
            "                <option value=\"eleven\">11</option>\n" +
            "                <option value=\"twelve\">12</option>\n" +
            "            </select>\n" +
            "            :\n" +
            "            <select name=\"setMin\">\n" +
		    "    			<option value=\"full\">00</option>\n" +
            "                <option value=\"half\">30</option>\n" +
            "            </select>\n" +
            "            <select>\n" +
		    "    			<option value=\"am\">AM</option>\n\n" +
            "                <option value=\"pm\">PM</option>" +
            "            </select></h4>\n" +
		        		
	        "		<li><h4>Maximum number of students\n" +
		    "    		<select name=\"setDate\">\n" +
		    "    			<option value=\"one\">01</option>\n" +
            "                <option value=\"two\">02</option>\n" +
            "                <option value=\"three\">03</option>\n" +
            "                <option value=\"four\">04</option>\n" +
            "                <option value=\"five\">05</option>\n" +
            "            </select></h4>\n" +
		    "    	</li>\n" +
		    "    	</li>\n" +
			"    </ul>" +
			"    <button type=\"submit\" class=\"setbtn\"><strong>Set</strong></button>\n" +
			"</div>\n" ;
			appointmentExtra.appendChild(d);
			appointmentExtra.appendChild(document.createElement("br"));
			}


			
			
			
		}

	</script>
</body>
</html>