<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
     <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>
    <style>
    	body {
    		background-color: #CCCCFF;
    	}
    	
    </style>
</head>
<body>
	<nav class="topnav" >
			<div class="container-fluid">
			    Sign Up
			</div>
		</nav>
	</nav>
	<div class="container">
		<div class="box1">
			<div class="row">
				<div class="col-md-9">
					<form name="supervisor" action="#">
						<h1>Supervisor Sign Up</h1>
						<hr>
						<p>
							<label for="firstName"><b>First Name</b></label><br>
							<input type="text" placeholder="Enter First Name" name="firstName" required="true">
						</p>
						<p>
							<label for="lastName"><b>Last Name</b></label><br>
							<input type="text" placeholder="Enter Last Name" name="lastName" required="true">
						</p>
						<p>
							<label for="email"><b>Email</b></label><br>
							<input type="text" placeholder="Enter Email" name="email" required="true">
						</p>
						<p>
							<label for="username"><b>Username</b></label><br>
							<input type="text" placeholder="Enter Username" name="username" required="true">
						</p>
						<p>
							<label for="password"><b>Password</b></label><br>
							<input type="text" placeholder="Password" name="password" required="true">
						</p>
						<a href="view_appointment.php"><button type="submit" class="signupbtn">Sign Up</button></a>
			            <br>
			            <p>Already have an account?<a href="index.php">Login</a></p>
			        </form>
				</div>
				<div class="col-md-3">
					<div class="profilePic">
			        	<img src="profile.jpg" alt="Avatar" style="width: 200px">
			        	<h4><b>Upload a profile picture</h4>
			        </div>
				</div>
			</div>
        </div>
    </div>
</body>
</html>