<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Simple Responsive Admin</title>
	    <link href="css/bootstrap.css" rel="stylesheet" />
      <link href="css/font-awesome.css" rel="stylesheet" />
      <link href="css/custom.css" rel="stylesheet" />
      <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
</head>
<body>
  <div class="wrapper">
    <!-- Sidebar -->
    <div class="row">
      <div class="col-md-2">
        <nav id="sidebar">
          <div class="sidebar-header">
              
          </div>

          <ul class="list-unstyled components">
            <li class="active">
              <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Home</a>
              <ul class="collapse list-unstyled" id="homeSubmenu">
                <li><a href="#">Home 1</a></li>
                <li><a href="#">Home 2</a></li>
                <li><a href="#">Home 3</a></li>
              </ul>
            </li>
            <li>
              <a href="#">About</a>
              <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Pages</a>
              <ul class="collapse list-unstyled" id="pageSubmenu">
                <li><a href="#">Page 1</a></li>
                <li><a href="#">Page 2</a></li>
                <li><a href="#">Page 3</a></li>
              </ul>
            </li>
            <li>
              <a href="#">Portfolio</a>
            </li>
            <li>
              <a href="#">Contact</a>
            </li>
          </ul>
          <ul class="list-unstyled CTAs">
            <li><a href="https://bootstrapious.com/tutorial/files/sidebar.zip" class="download">Download source</a></li>
            <li><a href="https://bootstrapious.com/p/bootstrap-sidebar" class="article">Back to article</a></li>
          </ul>
        </nav>
      </div>
    </div>
    

    <!-- Page Content -->
    <div class="row">
      <div class="col-md-10">
        <div id="page-inner">
          <div class="row">
            <div class="col-lg-9">
             <h2>ADMIN DASHBOARD</h2>   
            </div>
          </div>              
          <hr />

          <div class="row">
            <div class="col-lg-12 ">
              <div class="alert alert-info">
                <strong>Welcome Jhon Doe ! </strong> You Have No pending Task For Today.
              </div>
            </div>
          </div>
              <!-- /. ROW  --> 
          <div class="row text-center pad-top">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
              <div class="div-square">
                <a href="blank.html" >
                  <i class="fa fa-circle-o-notch fa-5x"></i>
                  <h4>Check Data</h4>
                </a>
              </div>
          </div> 
           
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
            <div class="div-square">
              <a href="blank.html" >
                <i class="fa fa-envelope-o fa-5x"></i>
                <h4>Mail Box</h4>
              </a>
            </div>
          </div>

          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
            <div class="div-square">
              <a href="blank.html" >
                <i class="fa fa-lightbulb-o fa-5x"></i>
                <h4>New Issues</h4>
              </a>
            </div>
          </div>

          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
            <div class="div-square">
              <a href="blank.html" >
                <i class="fa fa-users fa-5x"></i>
                <h4>See Users</h4>
              </a>
            </div>
          </div>

          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
            <div class="div-square">
               <a href="blank.html" >
                  <i class="fa fa-key fa-5x"></i>
                  <h4>Admin </h4>
              </a>
            </div>  
          </div>
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
            <div class="div-square">
                <a href="blank.html" >
                  <i class="fa fa-comments-o fa-5x"></i>
                  <h4>Support</h4>
                </a>
            </div>    
          </div>   
        </div>
      </div>
    </div>
    
  </div>     
    <!-- /. NAV TOP  -->
    <!--<nav class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">
             


                <li class="active-link">
                    <a href="index.html" ><i class="fa fa-desktop "></i>Dashboard <span class="badge">Included</span></a>
                </li>
               
                <li>
                    <a href="#"><i class="fa fa-qrcode "></i>Schedule</a>
                    <ul>
                      <li><a href="index.html" >
                        First Semester
                        <ul>
                          <li>Wednesday 3pm - 6pm</li>
                          <li>Saturday 3pm - 5pm</li>
                        </ul>
                      </li>
                      <li>
                        Second Semester
                      </li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-bar-chart-o"></i>My Link Two</a>
                </li>

                <li>
                    <a href="#"><i class="fa fa-edit "></i>My Link Three </a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-table "></i>My Link Four</a>
                </li>
                 <li>
                    <a href="#"><i class="fa fa-edit "></i>My Link Five </a>
                </li>
                
            </ul>
                        </div>

    </nav>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        
             <!-- /. ROW  -->   
		  <div class="row">
                <div class="col-lg-12 ">
			<br/>
                    <div class="alert alert-danger">
                         <strong>Want More Icons Free ? </strong> Checkout fontawesome website and use any icon <a target="_blank" href="http://fortawesome.github.io/Font-Awesome/icons/">Click Here</a>.
                    </div>
                   
                </div>
                </div>
              <!-- /. ROW  --> 
</div>
         <!-- /. PAGE INNER  -->
        </div>
     <!-- /. PAGE WRAPPER  -->
    </div>
<div class="footer">
  

        <div class="row">
            <div class="col-lg-12" >
               
            </div>
        </div>
    </div>
      

    
 
    <!--<script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>-->
    
    <script type="text/javascript">
      $(document).ready(function () {
        $("#sidebar").mCustomScrollbar({
            theme: "minimal"
        });

        $('#sidebarCollapse').on('click', function () {
          $('#sidebar, #content').toggleClass('active');
          $('.collapse.in').toggleClass('in');
          $('a[aria-expanded=true]').attr('aria-expanded', 'false');
        });
      });
    </script>
   
</body>
</html>
